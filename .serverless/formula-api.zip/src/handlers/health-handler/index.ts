import { health } from "./health-handler";

export { health as handler };
