import { userPost } from "./user-post-handler";

export { userPost as handler };
