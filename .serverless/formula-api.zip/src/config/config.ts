// Auth
// const TOKEN_HEADER = "x-forwarded-google-oauth-token";
const TOKEN_VALIDATION_URL = "https://www.googleapis.com/oauth2/v3/tokeninfo";

// Database
const TABLE_NAME = "FORMULA_MAIN";

export { TABLE_NAME, TOKEN_VALIDATION_URL };
