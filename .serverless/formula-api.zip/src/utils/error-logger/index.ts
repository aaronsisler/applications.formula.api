import { errorLogger } from "./error-logger";

export { errorLogger };
