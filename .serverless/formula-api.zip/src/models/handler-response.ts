export interface HandlerResponse {
  statusCode: number;
  body: string;
}
