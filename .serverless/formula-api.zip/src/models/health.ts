export interface Health {
  message: string;
  currentTime: string;
}
