import { AuthService } from "./auth-service";

export { AuthService };
