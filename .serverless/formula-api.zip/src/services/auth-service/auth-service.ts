class AuthService {}

export { AuthService };
