import { DatabaseService } from "./database-service";

export { DatabaseService };
